use crate::observation::Observation;

#[derive(Debug, Clone, PartialEq)]
pub struct MetricSet {
    pub structural_score: f64,
    pub transition_detection_score: f64,
    pub branch_detection_score: f64,
    pub null_false_positive_rate: Option<f64>,
    pub adversarial_acceptance_rate: Option<f64>,
    pub boundary_score: Option<f64>,
}

pub fn structural_score(obs: &Observation) -> f64 {
    if obs.sample_count == 0 { return 0.0; }
    let active = obs.phase_scores.iter()
        .filter(|p| p.tension > 0.0 || p.criticality > 0.0)
        .count();
    active as f64 / obs.sample_count as f64
}

pub fn transition_score(obs: &Observation) -> f64 {
    if obs.sample_count < 2 { return 0.0; }
    let expected = (obs.sample_count as f64 * 0.05).max(1.0);
    (obs.transitions.len() as f64 / expected).min(1.0)
}

pub fn branch_score(obs: &Observation) -> f64 {
    if obs.transitions.is_empty() { return 0.0; }
    let distinct = obs.branches.iter().map(|b| b.branch.as_str()).collect::<std::collections::BTreeSet<_>>().len();
    if distinct >= 2 { 1.0 } else { 0.5 }
}

pub fn compute(obs: &Observation) -> MetricSet {
    MetricSet {
        structural_score: structural_score(obs),
        transition_detection_score: transition_score(obs),
        branch_detection_score: branch_score(obs),
        null_false_positive_rate: None,
        adversarial_acceptance_rate: None,
        boundary_score: None,
    }
}
