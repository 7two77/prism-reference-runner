#[derive(Debug, Clone, PartialEq)]
pub struct Observation {
    pub dataset_id: String,
    pub sample_count: usize,
    pub mean: f64,
    pub variance: f64,
    pub lag1_autocorrelation: f64,
    pub phase_scores: Vec<PhaseScores>,
    pub transitions: Vec<TransitionObservation>,
    pub branches: Vec<BranchObservation>,
}

#[derive(Debug, Clone, PartialEq)]
pub struct PhaseScores {
    pub index: usize,
    pub accumulation: f64,
    pub tension: f64,
    pub criticality: f64,
    pub release: f64,
    pub reorganization: f64,
}

#[derive(Debug, Clone, PartialEq)]
pub struct TransitionObservation {
    pub from_index: usize,
    pub to_index: usize,
    pub magnitude: f64,
}

#[derive(Debug, Clone, PartialEq)]
pub struct BranchObservation {
    pub index: usize,
    pub branch: String,
}

pub fn observe(dataset_id: &str, samples: &[f64]) -> Observation {
    let n = samples.len();
    let mean = if n == 0 { 0.0 } else { samples.iter().sum::<f64>() / n as f64 };
    let variance = if n < 2 {
        0.0
    } else {
        samples.iter().map(|x| (x - mean).powi(2)).sum::<f64>() / (n - 1) as f64
    };

    let lag1 = if n < 3 || variance == 0.0 {
        0.0
    } else {
        let mut num = 0.0;
        for i in 1..n {
            num += (samples[i] - mean) * (samples[i - 1] - mean);
        }
        num / ((n - 1) as f64 * variance)
    };

    // Domain-independent first reference operator:
    // local normalized level/change proxies only.
    let scale = variance.sqrt().max(1e-12);
    let mut phases = Vec::with_capacity(n);
    for i in 0..n {
        let prev = if i == 0 { samples[i] } else { samples[i - 1] };
        let next = if i + 1 < n { samples[i + 1] } else { samples[i] };
        let delta = next - prev;
        let local = (samples[i] - mean) / scale;

        let accumulation = (-local).max(0.0).min(1.0);
        let tension = delta.abs() / scale;
        let criticality = (tension / (1.0 + tension)).min(1.0);
        let release = delta.max(0.0) / (scale + delta.abs()).max(1e-12);
        let reorganization = (local.abs() / (1.0 + local.abs())).min(1.0);

        phases.push(PhaseScores {
            index: i,
            accumulation,
            tension,
            criticality,
            release,
            reorganization,
        });
    }

    let mut transitions = Vec::new();
    for i in 1..n {
        let magnitude = (samples[i] - samples[i - 1]).abs();
        if magnitude > scale {
            transitions.push(TransitionObservation {
                from_index: i - 1,
                to_index: i,
                magnitude,
            });
        }
    }

    let branches = transitions.iter().map(|t| BranchObservation {
        index: t.to_index,
        branch: if samples[t.to_index] >= samples[t.from_index] {
            "positive".to_string()
        } else {
            "negative".to_string()
        },
    }).collect();

    Observation {
        dataset_id: dataset_id.to_string(),
        sample_count: n,
        mean,
        variance,
        lag1_autocorrelation: lag1,
        phase_scores: phases,
        transitions,
        branches,
    }
}
