#[derive(Debug, Clone)]
pub struct MatchedNullConfig {
    pub sample_count: usize,
    pub mean: f64,
    pub stddev: f64,
    pub phi: f64,
    pub seed: u64,
}

#[derive(Debug, Clone)]
pub struct MatchedNullDataset {
    pub generator_version: String,
    pub seed: u64,
    pub samples: Vec<f64>,
    pub preserved_properties: Vec<String>,
    pub destroyed_properties: Vec<String>,
}

pub fn generate(cfg: &MatchedNullConfig) -> MatchedNullDataset {
    // Deterministic AR(1)-style surrogate. It preserves first-order dependence
    // approximately while containing no P-0001 latent phase machine.
    let mut x = vec![cfg.mean; cfg.sample_count];
    let mut state = cfg.seed;
    for i in 1..cfg.sample_count {
        state = state.wrapping_mul(6364136223846793005).wrapping_add(1);
        let u = ((state >> 33) as f64) / ((1u64 << 31) as f64);
        let noise = (u * 2.0 - 1.0) * cfg.stddev;
        x[i] = cfg.mean + cfg.phi * (x[i - 1] - cfg.mean) + noise;
    }
    MatchedNullDataset {
        generator_version: "null-v0.2".to_string(),
        seed: cfg.seed,
        samples: x,
        preserved_properties: vec![
            "sample_count".to_string(),
            "target_mean".to_string(),
            "target_scale".to_string(),
            "first_order_dependence".to_string(),
        ],
        destroyed_properties: vec![
            "P-0001-target-topology".to_string(),
        ],
    }
}
