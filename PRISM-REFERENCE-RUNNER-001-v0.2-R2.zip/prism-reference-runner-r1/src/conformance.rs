use crate::{metrics::MetricSet, observation::Observation};

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DimensionStatus { Pass, Fail, Unidentified, NotApplicable }

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum RunStatus { Pass, Fail, Invalid }

#[derive(Debug, Clone, PartialEq)]
pub struct ConformanceResult {
    pub protocol_id: String,
    pub pattern_id: String,
    pub pattern_version: String,
    pub dataset_id: String,
    pub structural: DimensionStatus,
    pub temporal: DimensionStatus,
    pub statistical: DimensionStatus,
    pub oos: DimensionStatus,
    pub replication: DimensionStatus,
    pub status: RunStatus,
}

pub fn evaluate(
    protocol_id: &str,
    pattern_id: &str,
    pattern_version: &str,
    obs: &Observation,
    metrics: &MetricSet,
) -> ConformanceResult {
    // R2 intentionally uses only implementation-level reference decisions.
    // Thresholds belong to the frozen protocol; these are conservative placeholders
    // until the exact serialized protocol thresholds are available.
    let structural = if metrics.structural_score >= 0.50 {
        DimensionStatus::Pass
    } else {
        DimensionStatus::Fail
    };
    let temporal = if metrics.transition_detection_score >= 0.50 {
        DimensionStatus::Pass
    } else {
        DimensionStatus::Fail
    };
    let statistical = DimensionStatus::Unidentified;
    let oos = DimensionStatus::NotApplicable;
    let replication = DimensionStatus::NotApplicable;

    let status = if obs.sample_count == 0 {
        RunStatus::Invalid
    } else if structural == DimensionStatus::Pass && temporal == DimensionStatus::Pass {
        RunStatus::Pass
    } else {
        RunStatus::Fail
    };

    ConformanceResult {
        protocol_id: protocol_id.to_string(),
        pattern_id: pattern_id.to_string(),
        pattern_version: pattern_version.to_string(),
        dataset_id: obs.dataset_id.clone(),
        structural,
        temporal,
        statistical,
        oos,
        replication,
        status,
    }
}
