use crate::{conformance::{evaluate, ConformanceResult}, metrics::{compute, MetricSet}, observation::{observe, Observation}};

#[derive(Debug, Clone, PartialEq)]
pub struct RunResult {
    pub run_id: String,
    pub pattern_id: String,
    pub pattern_version: String,
    pub protocol_id: String,
    pub dataset_id: String,
    pub observation: Observation,
    pub metrics: MetricSet,
    pub conformance: ConformanceResult,
}

pub fn execute(
    run_id: &str,
    pattern_id: &str,
    pattern_version: &str,
    protocol_id: &str,
    dataset_id: &str,
    samples: &[f64],
) -> RunResult {
    let observation = observe(dataset_id, samples);
    let metrics = compute(&observation);
    let conformance = evaluate(
        protocol_id,
        pattern_id,
        pattern_version,
        &observation,
        &metrics,
    );

    RunResult {
        run_id: run_id.to_string(),
        pattern_id: pattern_id.to_string(),
        pattern_version: pattern_version.to_string(),
        protocol_id: protocol_id.to_string(),
        dataset_id: dataset_id.to_string(),
        observation,
        metrics,
        conformance,
    }
}
