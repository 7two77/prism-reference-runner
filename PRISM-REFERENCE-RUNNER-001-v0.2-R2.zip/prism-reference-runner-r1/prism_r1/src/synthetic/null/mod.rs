use super::super::generator::*;
pub struct NullGenerator;
impl SyntheticGenerator for NullGenerator {
    fn generate(&self, seed:u64, samples:usize)->Dataset {
        let mut x=seed ^ 0xD1B54A32D192ED03; let mut out=Vec::with_capacity(samples);
        for t in 0..samples { x ^= x<<7; x ^= x>>9; x ^= x<<8; let noise=((x%10000)as f64/10000.0)-0.5; out.push(Sample{t,values:vec![noise]}); }
        Dataset{dataset_id:format!("SYN-B-{seed}"),control_class:ControlClass::Null,generator_version:"null-v0.1".into(),seed,parameters:vec![("target_topology".into(),"absent".into())],samples:out}
    }
}
