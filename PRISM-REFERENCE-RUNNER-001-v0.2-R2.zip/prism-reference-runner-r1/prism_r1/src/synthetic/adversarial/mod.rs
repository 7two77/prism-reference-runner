use super::super::generator::*;
pub struct AdversarialGenerator;
impl SyntheticGenerator for AdversarialGenerator {
    fn generate(&self, seed:u64, samples:usize)->Dataset {
        let mut x=seed ^ 0x94D049BB133111EB; let mut out=Vec::with_capacity(samples);
        for t in 0..samples { x^=x<<7;x^=x>>9;x^=x<<8; let noise=((x%10000)as f64/10000.0)-0.5; let u=t as f64/samples.max(1) as f64; let value=(u*2.0 + (u*18.0).sin()*0.2 + noise*0.05); out.push(Sample{t,values:vec![value]}); }
        Dataset{dataset_id:format!("SYN-C-{seed}"),control_class:ControlClass::Adversarial,generator_version:"adversarial-v0.1".into(),seed,parameters:vec![("violated_invariant".into(),"INV-001".into())],samples:out}
    }
}
