use super::super::generator::*;
pub struct BoundaryGenerator { pub lambda:f64 }
impl SyntheticGenerator for BoundaryGenerator {
    fn generate(&self, seed:u64, samples:usize)->Dataset {
        let mut x=seed ^ 0xA24BAED4963EE407; let mut out=Vec::with_capacity(samples);
        for t in 0..samples { x^=x<<7;x^=x>>9;x^=x<<8; let noise=((x%10000)as f64/10000.0)-0.5; let u=t as f64/samples.max(1) as f64; let signal=if u<0.55 {u*2.0} else {1.1-(u-0.55)*1.5}; let value=self.lambda*signal+(1.0-self.lambda)*noise; out.push(Sample{t,values:vec![value]}); }
        Dataset{dataset_id:format!("SYN-D-{seed}-L{:.2}",self.lambda),control_class:ControlClass::Boundary,generator_version:"boundary-v0.1".into(),seed,parameters:vec![("lambda".into(),format!("{:.6}",self.lambda))],samples:out}
    }
}
