use super::super::generator::*;

pub struct PositiveGenerator;
impl SyntheticGenerator for PositiveGenerator {
    fn generate(&self, seed: u64, samples: usize) -> Dataset {
        // Deterministic reference generator; latent state is deliberately not exported.
        let mut x = seed ^ 0x9E3779B97F4A7C15;
        let mut out=Vec::with_capacity(samples);
        for t in 0..samples {
            x ^= x << 7; x ^= x >> 9; x ^= x << 8;
            let noise=((x % 10_000) as f64 / 10_000.0)-0.5;
            let u=t as f64/(samples.max(1) as f64);
            let value=if u<0.35 {u*2.0} else if u<0.55 {0.7+(u-0.35)*2.0} else if u<0.65 {1.1+(u-0.55)*4.0} else if u<0.75 {1.5+(u-0.65)*3.0} else {0.2+(u-0.75)*0.5} + noise*0.05;
            out.push(Sample{t,values:vec![value]});
        }
        Dataset{dataset_id:format!("SYN-A-{seed}"),control_class:ControlClass::Positive,generator_version:"positive-v0.1".into(),seed,parameters:vec![("topology".into(),"P-0001".into())],samples:out}
    }
}
