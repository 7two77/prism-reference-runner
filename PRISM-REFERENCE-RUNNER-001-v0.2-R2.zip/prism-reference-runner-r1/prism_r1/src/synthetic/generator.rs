#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ControlClass { Positive, Null, Adversarial, Boundary }

#[derive(Debug, Clone, PartialEq)]
pub struct Sample { pub t: usize, pub values: Vec<f64> }

#[derive(Debug, Clone, PartialEq)]
pub struct Dataset {
    pub dataset_id: String,
    pub control_class: ControlClass,
    pub generator_version: String,
    pub seed: u64,
    pub parameters: Vec<(String, String)>,
    pub samples: Vec<Sample>,
}

pub trait SyntheticGenerator {
    fn generate(&self, seed: u64, samples: usize) -> Dataset;
}
