use crate::pattern::PatternVersion;

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProtocolVersion { pub id: String, pub major: u32, pub minor: u32 }

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct DatasetSpec { pub realizations: usize, pub samples_per_realization: usize, pub scale: String }

#[derive(Debug, Clone, PartialEq)]
pub struct DecisionRules { pub structural_threshold: f64, pub adversarial_max_acceptance: f64, pub null_max_fpr: f64 }

#[derive(Debug, Clone, PartialEq)]
pub struct ConformanceProtocol {
    pub version: ProtocolVersion,
    pub target_pattern: PatternVersion,
    pub dataset_spec: DatasetSpec,
    pub seed_base: u64,
    pub decision_rules: DecisionRules,
}
