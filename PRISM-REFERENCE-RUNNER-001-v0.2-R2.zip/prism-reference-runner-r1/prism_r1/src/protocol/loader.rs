use std::{fs, path::Path};
use super::model::*;
use crate::pattern::PatternVersion;

#[derive(Debug)]
pub enum ProtocolLoadError { Io(std::io::Error), InvalidFormat(String) }
impl From<std::io::Error> for ProtocolLoadError { fn from(v: std::io::Error) -> Self { Self::Io(v) } }

pub fn load_protocol(path: impl AsRef<Path>) -> Result<ConformanceProtocol, ProtocolLoadError> {
    let text = fs::read_to_string(path)?;
    let mut protocol = None;
    let mut target = None;
    let mut realizations = None;
    let mut samples = None;
    let mut scale = None;
    let mut seed = None;
    let mut structural = None;
    let mut adv = None;
    let mut null_fpr = None;
    let mut section = "";

    for raw in text.lines() {
        let line = raw.trim();
        if line.is_empty() || line.starts_with('#') { continue; }
        if line.starts_with('[') && line.ends_with(']') { section = &line[1..line.len()-1]; continue; }
        let Some((k,v)) = line.split_once('=') else { return Err(ProtocolLoadError::InvalidFormat(line.into())); };
        let k=k.trim(); let v=v.trim().trim_matches('"');
        match (section,k) {
            ("identity","protocol") => { let (id,ver)=v.split_once('@').ok_or_else(|| ProtocolLoadError::InvalidFormat(v.into()))?; let (a,b)=ver.split_once('.').ok_or_else(|| ProtocolLoadError::InvalidFormat(v.into()))?; protocol=Some(ProtocolVersion{id:id.into(),major:a.parse().map_err(|_|ProtocolLoadError::InvalidFormat(v.into()))?,minor:b.parse().map_err(|_|ProtocolLoadError::InvalidFormat(v.into()))?}); }
            ("target","pattern") => target=PatternVersion::parse(v),
            ("dataset","realizations") => realizations=v.parse().ok(),
            ("dataset","samples_per_realization") => samples=v.parse().ok(),
            ("dataset","scale") => scale=Some(v.into()),
            ("execution","seed_base") => seed=v.parse().ok(),
            ("decision","structural_threshold") => structural=v.parse().ok(),
            ("decision","adversarial_max_acceptance") => adv=v.parse().ok(),
            ("decision","null_max_fpr") => null_fpr=v.parse().ok(),
            _ => {}
        }
    }
    Ok(ConformanceProtocol {
        version: protocol.ok_or_else(||ProtocolLoadError::InvalidFormat("missing protocol".into()))?,
        target_pattern: target.ok_or_else(||ProtocolLoadError::InvalidFormat("missing target.pattern".into()))?,
        dataset_spec: DatasetSpec { realizations: realizations.ok_or_else(||ProtocolLoadError::InvalidFormat("missing realizations".into()))?, samples_per_realization: samples.ok_or_else(||ProtocolLoadError::InvalidFormat("missing samples_per_realization".into()))?, scale: scale.ok_or_else(||ProtocolLoadError::InvalidFormat("missing scale".into()))? },
        seed_base: seed.ok_or_else(||ProtocolLoadError::InvalidFormat("missing seed_base".into()))?,
        decision_rules: DecisionRules { structural_threshold: structural.ok_or_else(||ProtocolLoadError::InvalidFormat("missing structural threshold".into()))?, adversarial_max_acceptance: adv.ok_or_else(||ProtocolLoadError::InvalidFormat("missing adversarial threshold".into()))?, null_max_fpr: null_fpr.ok_or_else(||ProtocolLoadError::InvalidFormat("missing null threshold".into()))? },
    })
}
