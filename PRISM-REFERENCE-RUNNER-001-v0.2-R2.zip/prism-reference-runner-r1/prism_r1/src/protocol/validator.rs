use super::model::ConformanceProtocol;

#[derive(Debug)]
pub enum ProtocolValidationError { WrongIdentity, TargetMismatch, InvalidSampleSize, InvalidRealizations, InvalidThreshold }

pub fn validate_protocol(p: &ConformanceProtocol) -> Result<(), ProtocolValidationError> {
    if p.version.id != "PRISM-CONFORMANCE-001" || p.version.major != 0 || p.version.minor != 1 { return Err(ProtocolValidationError::WrongIdentity); }
    if p.target_pattern.pattern_id != "P-0001" || p.target_pattern.major != 0 || p.target_pattern.minor != 1 { return Err(ProtocolValidationError::TargetMismatch); }
    if p.dataset_spec.realizations == 0 { return Err(ProtocolValidationError::InvalidRealizations); }
    if p.dataset_spec.samples_per_realization < 10 { return Err(ProtocolValidationError::InvalidSampleSize); }
    let d=&p.decision_rules;
    if !(0.0..=1.0).contains(&d.structural_threshold) || !(0.0..=1.0).contains(&d.adversarial_max_acceptance) || !(0.0..=1.0).contains(&d.null_max_fpr) { return Err(ProtocolValidationError::InvalidThreshold); }
    Ok(())
}
