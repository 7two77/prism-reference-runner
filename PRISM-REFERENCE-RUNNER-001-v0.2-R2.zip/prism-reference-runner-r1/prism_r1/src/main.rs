use std::env;
use prism_reference_runner::pattern::{load_pattern, validate_pattern};
use prism_reference_runner::protocol::{load_protocol, validate_protocol};
use prism_reference_runner::synthetic::{SyntheticGenerator};
use prism_reference_runner::synthetic::positive::PositiveGenerator;

fn main() {
    let args: Vec<String> = env::args().collect();
    if args.len() != 3 {
        eprintln!("usage: prism-reference-runner <pattern> <protocol>");
        std::process::exit(2);
    }
    let pattern = load_pattern(&args[1]).expect("pattern load failed");
    validate_pattern(&pattern).expect("pattern validation failed");
    let protocol = load_protocol(&args[2]).expect("protocol load failed");
    validate_protocol(&protocol).expect("protocol validation failed");
    assert_eq!(pattern.version, protocol.target_pattern);
    let ds = PositiveGenerator.generate(protocol.seed_base, protocol.dataset_spec.samples_per_realization);
    println!("R1 LOAD/PRECHECK PASS");
    println!("pattern={}", pattern.version.as_ref());
    println!("protocol={}@{}.{}", protocol.version.id, protocol.version.major, protocol.version.minor);
    println!("dataset={} samples={}", ds.dataset_id, ds.samples.len());
}
