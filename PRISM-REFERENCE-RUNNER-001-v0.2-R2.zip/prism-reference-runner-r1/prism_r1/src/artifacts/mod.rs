//! Reserved implementation boundary for R1.
