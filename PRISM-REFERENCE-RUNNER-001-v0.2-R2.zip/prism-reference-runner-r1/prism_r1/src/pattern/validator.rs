use super::ir::{InvariantId, Node, PatternIr};

#[derive(Debug)]
pub enum PatternValidationError {
    WrongIdentity,
    MissingNode(Node),
    MissingEdge(Node, Node),
    MissingInvariant(InvariantId),
    MissingObservableRole(&'static str),
    ForbiddenDomainMeasurement,
}

pub fn validate_pattern(p: &PatternIr) -> Result<(), PatternValidationError> {
    if p.version.pattern_id != "P-0001" || p.version.major != 0 || p.version.minor != 1 {
        return Err(PatternValidationError::WrongIdentity);
    }
    for node in [Node::S0, Node::A, Node::T, Node::C, Node::B, Node::R, Node::N] {
        if !p.nodes.contains(&node) { return Err(PatternValidationError::MissingNode(node)); }
    }
    for edge in [
        (Node::S0, Node::A), (Node::A, Node::T), (Node::A, Node::S0),
        (Node::T, Node::C), (Node::T, Node::A), (Node::C, Node::C),
        (Node::C, Node::T), (Node::C, Node::B), (Node::B, Node::R),
        (Node::R, Node::N),
    ] {
        if !p.edges.contains(&edge) { return Err(PatternValidationError::MissingEdge(edge.0, edge.1)); }
    }
    for inv in [
        InvariantId::Inv001, InvariantId::Inv002, InvariantId::Inv003, InvariantId::Inv004,
        InvariantId::Inv005, InvariantId::Inv006, InvariantId::Inv007, InvariantId::Inv008,
    ] {
        if !p.invariants.contains(&inv) { return Err(PatternValidationError::MissingInvariant(inv)); }
    }
    for role in [
        "ACCUMULATION_PROXY", "TENSION_PROXY", "CRITICALITY_PROXY",
        "TRANSITION_PROXY", "REORGANIZATION_PROXY", "PERSISTENCE_PROXY",
        "CONNECTIVITY_PROXY", "STRUCTURAL_ENTROPY_PROXY",
    ] {
        if !p.observable_roles.iter().any(|x| x == role) {
            return Err(PatternValidationError::MissingObservableRole(role));
        }
    }
    if p.observable_roles.iter().any(|r| r == "VOLUME" || r == "ATR" || r == "BB_WIDTH") {
        return Err(PatternValidationError::ForbiddenDomainMeasurement);
    }
    Ok(())
}
