pub mod ir;
pub mod loader;
pub mod validator;

pub use ir::{InvariantId, Node, PatternIr, PatternVersion};
pub use loader::{load_pattern, PatternLoadError};
pub use validator::{validate_pattern, PatternValidationError};
