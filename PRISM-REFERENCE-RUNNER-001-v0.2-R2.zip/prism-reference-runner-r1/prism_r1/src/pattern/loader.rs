use std::{fs, path::Path};
use super::ir::{InvariantId, Node, PatternIr, PatternVersion};

#[derive(Debug)]
pub enum PatternLoadError {
    Io(std::io::Error),
    InvalidFormat(String),
}

impl From<std::io::Error> for PatternLoadError {
    fn from(value: std::io::Error) -> Self { Self::Io(value) }
}

pub fn load_pattern(path: impl AsRef<Path>) -> Result<PatternIr, PatternLoadError> {
    let text = fs::read_to_string(path)?;
    let mut id = None;
    let mut origin_claim = None;
    let mut roles = Vec::new();
    let mut invariants = Vec::new();
    let mut section = "";

    for raw in text.lines() {
        let line = raw.trim();
        if line.is_empty() || line.starts_with('#') { continue; }
        if line.starts_with('[') && line.ends_with(']') {
            section = &line[1..line.len()-1];
            continue;
        }
        let Some((k, v)) = line.split_once('=') else {
            return Err(PatternLoadError::InvalidFormat(line.to_owned()));
        };
        let k = k.trim();
        let v = v.trim().trim_matches('"');
        match (section, k) {
            ("identity", "pattern") => id = PatternVersion::parse(v),
            ("origin", "claim") => origin_claim = Some(v.to_owned()),
            ("observable_roles", "role") => roles.push(v.to_owned()),
            ("invariants", "id") => invariants.push(match v {
                "INV-001" => InvariantId::Inv001,
                "INV-002" => InvariantId::Inv002,
                "INV-003" => InvariantId::Inv003,
                "INV-004" => InvariantId::Inv004,
                "INV-005" => InvariantId::Inv005,
                "INV-006" => InvariantId::Inv006,
                "INV-007" => InvariantId::Inv007,
                "INV-008" => InvariantId::Inv008,
                _ => return Err(PatternLoadError::InvalidFormat(format!("unknown invariant {v}"))),
            }),
            _ => {}
        }
    }

    let version = id.ok_or_else(|| PatternLoadError::InvalidFormat("missing identity.pattern".into()))?;
    let origin_claim = origin_claim.ok_or_else(|| PatternLoadError::InvalidFormat("missing origin.claim".into()))?;

    let nodes = vec![Node::S0, Node::A, Node::T, Node::C, Node::B, Node::R, Node::N];
    let edges = vec![
        (Node::S0, Node::A), (Node::A, Node::T), (Node::A, Node::S0),
        (Node::T, Node::C), (Node::T, Node::A), (Node::C, Node::C),
        (Node::C, Node::T), (Node::C, Node::B), (Node::B, Node::R),
        (Node::R, Node::N),
    ];

    Ok(PatternIr {
        version,
        origin_claim,
        nodes,
        edges,
        invariants,
        observable_roles: roles,
        causal_schemas: vec![(Node::A, Node::C), (Node::C, Node::R), (Node::R, Node::N)],
        scale_model: "GENERIC".into(),
        recurrence_model: "OPTIONAL / OBSERVATIONAL".into(),
    })
}
