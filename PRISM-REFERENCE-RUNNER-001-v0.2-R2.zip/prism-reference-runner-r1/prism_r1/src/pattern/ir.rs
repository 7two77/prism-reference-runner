#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PatternVersion {
    pub pattern_id: String,
    pub major: u32,
    pub minor: u32,
}

impl PatternVersion {
    pub fn parse(value: &str) -> Option<Self> {
        let (id, version) = value.split_once('@')?;
        let (major, minor) = version.split_once('.')?;
        Some(Self {
            pattern_id: id.to_owned(),
            major: major.parse().ok()?,
            minor: minor.parse().ok()?,
        })
    }

    pub fn as_ref(&self) -> String {
        format!("{}@{}.{}", self.pattern_id, self.major, self.minor)
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Node {
    S0,
    A,
    T,
    C,
    B,
    R,
    N,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum InvariantId {
    Inv001,
    Inv002,
    Inv003,
    Inv004,
    Inv005,
    Inv006,
    Inv007,
    Inv008,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PatternIr {
    pub version: PatternVersion,
    pub origin_claim: String,
    pub nodes: Vec<Node>,
    pub edges: Vec<(Node, Node)>,
    pub invariants: Vec<InvariantId>,
    pub observable_roles: Vec<String>,
    pub causal_schemas: Vec<(Node, Node)>,
    pub scale_model: String,
    pub recurrence_model: String,
}
