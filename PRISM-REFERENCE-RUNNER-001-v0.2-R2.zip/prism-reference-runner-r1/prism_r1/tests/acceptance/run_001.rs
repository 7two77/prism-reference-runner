use prism_reference_runner::pattern::{load_pattern, validate_pattern};
use prism_reference_runner::protocol::{load_protocol, validate_protocol};
use prism_reference_runner::synthetic::{SyntheticGenerator, ControlClass};
use prism_reference_runner::synthetic::{positive::PositiveGenerator, null::NullGenerator, adversarial::AdversarialGenerator, boundary::BoundaryGenerator};

#[test]
fn run_001_r1_load_validate_generate_reproducibly() {
    let p=load_pattern("artifacts/P-0001@0.1.pattern").unwrap();
    validate_pattern(&p).unwrap();
    let protocol=load_protocol("artifacts/PRISM-CONFORMANCE-001@0.1.protocol").unwrap();
    validate_protocol(&protocol).unwrap();
    assert_eq!(p.version, protocol.target_pattern);

    let a1=PositiveGenerator.generate(protocol.seed_base, protocol.dataset_spec.samples_per_realization);
    let a2=PositiveGenerator.generate(protocol.seed_base, protocol.dataset_spec.samples_per_realization);
    assert_eq!(a1, a2);
    assert_eq!(a1.control_class, ControlClass::Positive);
    assert_eq!(a1.samples.len(), protocol.dataset_spec.samples_per_realization);

    let b=NullGenerator.generate(protocol.seed_base, protocol.dataset_spec.samples_per_realization);
    let c=AdversarialGenerator.generate(protocol.seed_base, protocol.dataset_spec.samples_per_realization);
    let d=BoundaryGenerator{lambda:0.5}.generate(protocol.seed_base, protocol.dataset_spec.samples_per_realization);
    assert_eq!(b.control_class, ControlClass::Null);
    assert_eq!(c.control_class, ControlClass::Adversarial);
    assert_eq!(d.control_class, ControlClass::Boundary);
}
