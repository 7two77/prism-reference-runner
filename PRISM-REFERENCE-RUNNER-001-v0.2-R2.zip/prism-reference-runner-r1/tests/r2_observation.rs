use prism_reference_runner::{observation::observe, metrics, run};

#[test]
fn observation_does_not_expose_latent_state() {
    let samples = vec![0.0, 0.1, 0.3, 0.8, 1.5, 0.2, -0.4, 0.0];
    let obs = observe("D-R2", &samples);
    assert_eq!(obs.sample_count, samples.len());
    assert_eq!(obs.dataset_id, "D-R2");
}

#[test]
fn metrics_are_derived_only_from_observation() {
    let samples = vec![0.0, 0.1, 0.3, 0.8, 1.5, 0.2, -0.4, 0.0];
    let obs = observe("D-R2", &samples);
    let m1 = metrics::compute(&obs);
    let m2 = metrics::compute(&obs);
    assert_eq!(m1, m2);
}

#[test]
fn run_produces_result_without_mutating_inputs() {
    let samples = vec![0.0, 0.2, 0.5, 1.0, 0.3, -0.2];
    let before = samples.clone();
    let result = run::execute(
        "RUN-R2-001",
        "P-0001",
        "0.1",
        "PRISM-CONFORMANCE-001",
        "D-R2-001",
        &samples,
    );
    assert_eq!(samples, before);
    assert_eq!(result.pattern_id, "P-0001");
    assert_eq!(result.pattern_version, "0.1");
}
